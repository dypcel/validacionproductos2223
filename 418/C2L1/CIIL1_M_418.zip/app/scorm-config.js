
    window.geniallyElearningPresetData = {
      gradeToComplete: 100,
      dataGeniallyOffline: window.dataGeniallyOffline
    };
      