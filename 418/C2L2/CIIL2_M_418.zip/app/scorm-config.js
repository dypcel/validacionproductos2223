
      window.geniallyElearningAccessPresetData = {
        dataGeniallyOffline: window.dataGeniallyOffline
      };
      